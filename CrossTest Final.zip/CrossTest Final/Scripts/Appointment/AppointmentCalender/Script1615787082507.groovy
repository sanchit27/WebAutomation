import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://stage.doctor.rgcross.com/')

WebUI.setText(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/input_Login with username_phone'), 
    '9014827517')

WebUI.setEncryptedText(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/input_Login with username_password'), 
    'YsqIKzHWQwYX7jcwa8U8RQ==')

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/span_LOGIN'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/span_NEW APPOINTMENT'))

WebUI.setText(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/input_BHEL Employee Id_text-normal-medium-2_2a6781'), 
    '9014827517')

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/p_Ira        Chaturvedi'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/button_NEXT'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/span_NEXT'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/div_Select Service_content'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/li_CONSULTATION'))

WebUI.setText(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/input'), '15-03-2021')

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/div_Appointment DateMarch2021SUNMONTUEWEDTH_397ed0'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/div_600 PM 0'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/label_WALK-IN'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/label_Follow up'))

WebUI.setText(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/textarea_Reason_form-control ng-untouched n_177a6e'), 
    'Test')

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/span_ADD APPOINTMENT'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/li_Cancel'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/input_1'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/li_Doctor Cancelled'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/span_Save'))

WebUI.click(findTestObject('Object Repository/CalenderNewAppointment/Page_RG Cross Doctors/p_Appointment Cancelled'))

WebUI.closeBrowser()

