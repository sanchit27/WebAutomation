import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://stage.doctor.rgcross.com/')

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/div_v1610_ngx-overlay foreground-closing'))

WebUI.setText(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/input_Login with username_phone'), '9014827517')

WebUI.setEncryptedText(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/input_Login with username_password'), 
    'YsqIKzHWQwYX7jcwa8U8RQ==')

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/div_LOGIN'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_Caregroup'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/img'))

WebUI.delay(3)

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_CARENOTE'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/section_CARENOTE'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_CHIEF COMPLAINTS'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_SYSTEMIC EXAM'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_VITALS'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_TRACKERS'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_DIAGNOSIS'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_ADVISED PROCEDURES'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_ORDERS'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_PRESCRIPTION'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/a_Allopathy'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/a_Homeopathy'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/a_Ayurveda'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/label_PATIENT INSTRUCTIONS'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/strong_ADD SECTION'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_Patient Updates'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_Medical Notes'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_Patient Updates'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_Medical Notes'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/path'))

WebUI.click(findTestObject('Object Repository/Carenote/Page_RG Cross Doctors/span_OK'))

WebUI.closeBrowser()

