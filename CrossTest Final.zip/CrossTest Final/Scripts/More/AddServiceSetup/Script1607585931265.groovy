import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://stage.doctor.rgcross.com/')

WebUI.setText(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/input_Login with username_phone'), 
    '9014827517')

WebUI.setEncryptedText(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/input_Login with username_password'), 
    'YsqIKzHWQwYX7jcwa8U8RQ==')

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/button_LOGIN'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/span_More'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/span_Service Setup'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/span_ADD SERVICE'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/span_Consultation'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/span_Follow up'))

WebUI.setText(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/input_Fee_form-control ng-untouched ng-vali_92548c'), 
    '199')

WebUI.setText(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/input_Service Name_form-control ng-untouche_b6a152'), 
    'auto')

WebUI.setText(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/input_Service Description_form-control ng-u_948fe0'), 
    'automation')

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/i_Duration_left-icon x-i-left-caret small n_5ac2c5'))

WebUI.delay(2)

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/li_15 minutes'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/i_Patients_left-icon x-i-left-caret small n_f296ff'))

WebUI.delay(2)

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/li_2'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/span_Save Preference'))

WebUI.click(findTestObject('Object Repository/ServiceSetupAdd/Page_RG Cross Doctors/p_Service added successfully'))

WebUI.closeBrowser()

