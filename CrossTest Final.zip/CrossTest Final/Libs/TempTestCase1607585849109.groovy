import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner
import com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner
import com.kms.katalon.core.testng.keyword.internal.TestNGDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.testng.keyword.internal.TestNGDriverCleaner())


RunConfiguration.setExecutionSettingFile('/var/folders/w6/0lb8xyfs1y95461bf19kmxj40000gp/T/Katalon/20201210_130729/execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runWSVerificationScript(new TestCaseBinding('',[:]), 'import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI\nimport com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile\nimport com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW\nimport com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS\nimport com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows\nimport static com.kms.katalon.core.testobject.ObjectRepository.findTestObject\nimport static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject\nimport static com.kms.katalon.core.testdata.TestDataFactory.findTestData\nimport static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase\nimport static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint\nimport com.kms.katalon.core.model.FailureHandling as FailureHandling\nimport com.kms.katalon.core.testcase.TestCase as TestCase\nimport com.kms.katalon.core.testdata.TestData as TestData\nimport com.kms.katalon.core.testobject.TestObject as TestObject\nimport com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint\nimport internal.GlobalVariable as GlobalVariable\nimport org.openqa.selenium.Keys as Keys\n\nWebUI.openBrowser(\'\')\n\nWebUI.navigateToUrl(\'https://stage.doctor.rgcross.com/\')\n\nWebUI.setText(findTestObject(\'Page_RG Cross Doctors/input_Login with username_phone\'), \'9014827517\')\n\nWebUI.setEncryptedText(findTestObject(\'Page_RG Cross Doctors/input_Login with username_password\'), \'YsqIKzHWQwYX7jcwa8U8RQ==\')\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/button_LOGIN\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/span_More\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/span_Service Setup\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/span_ADD SERVICE\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/span_Consultation\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/span_Follow up\'))\n\nWebUI.setText(findTestObject(\'Page_RG Cross Doctors/input_Fee_form-control ng-untouched ng-vali_92548c\'), \'199\')\n\nWebUI.setText(findTestObject(\'Page_RG Cross Doctors/input_Service Name_form-control ng-untouche_b6a152\'), \'auto\')\n\nWebUI.setText(findTestObject(\'Page_RG Cross Doctors/input_Service Description_form-control ng-u_948fe0\'), \'automation\')\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/i_Duration_left-icon x-i-left-caret small n_5ac2c5\'))\n\nWebUI.delay(2)\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/li_15 minutes\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/i_Patients_left-icon x-i-left-caret small n_f296ff\'))\n\nWebUI.delay(2)\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/li_2\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/span_Save Preference\'))\n\nWebUI.click(findTestObject(\'Page_RG Cross Doctors/p_Service added successfully\'))\n\nWebUI.closeBrowser()\n\n', FailureHandling.STOP_ON_FAILURE, true)

