<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Ive read and agree to the TERMS  CONDITIONS</name>
   <tag></tag>
   <elementGuidId>1c7f3e2e-5cad-4b6c-987a-96281f973b6c</elementGuidId>
   <imagePath></imagePath>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Resend'])[1]/following::span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.terms-text</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>/html[1]/body[1]/app-get-listed[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;verif&quot;]/app-verification[@class=&quot;ng-star-inserted&quot;]/rg-sso[1]/main[@class=&quot;rg-sso-main&quot;]/aside[@class=&quot;main-content&quot;]/div[@class=&quot;col-xs-4 col-sm-5 col-md-7 col-lg-8 view-container&quot;]/div[@class=&quot;screens-container&quot;]/rg-verification[@class=&quot;ng-star-inserted&quot;]/section[@class=&quot;contact-details ng-star-inserted&quot;]/section[@class=&quot;practitioner-verification ng-star-inserted&quot;]/section[@class=&quot;agree-terms ng-star-inserted&quot;]/span[@class=&quot;terms-text&quot;][count(. | //span[@class = 'terms-text' and (text() = 'I’ve read and agree to the TERMS &amp; CONDITIONS' or . = 'I’ve read and agree to the TERMS &amp; CONDITIONS')]) = count(//span[@class = 'terms-text' and (text() = 'I’ve read and agree to the TERMS &amp; CONDITIONS' or . = 'I’ve read and agree to the TERMS &amp; CONDITIONS')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>terms-text</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>I’ve read and agree to the TERMS &amp; CONDITIONS</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-get-listed[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;verif&quot;]/app-verification[@class=&quot;ng-star-inserted&quot;]/rg-sso[1]/main[@class=&quot;rg-sso-main&quot;]/aside[@class=&quot;main-content&quot;]/div[@class=&quot;col-xs-4 col-sm-5 col-md-7 col-lg-8 view-container&quot;]/div[@class=&quot;screens-container&quot;]/rg-verification[@class=&quot;ng-star-inserted&quot;]/section[@class=&quot;contact-details ng-star-inserted&quot;]/section[@class=&quot;practitioner-verification ng-star-inserted&quot;]/section[@class=&quot;agree-terms ng-star-inserted&quot;]/span[@class=&quot;terms-text&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Resend'])[1]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEND OTP'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='I’ve read and agree to the']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]</value>
   </webElementXpaths>
</WebElementEntity>
