<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Resend_ng-star-inserted</name>
   <tag></tag>
   <elementGuidId>591aae05-2dbd-4b78-bb7f-94c7ba4bfe70</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Resend'])[1]/preceding::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>section.input-otp.ng-star-inserted > x-textfield > div.x-i-textfield-wrapper > div.ng-star-inserted</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-get-listed[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;verif&quot;]/app-verification[@class=&quot;ng-star-inserted&quot;]/rg-sso[1]/main[@class=&quot;rg-sso-main&quot;]/aside[@class=&quot;main-content&quot;]/div[@class=&quot;col-xs-4 col-sm-5 col-md-7 col-lg-8 view-container&quot;]/div[@class=&quot;screens-container&quot;]/rg-verification[@class=&quot;ng-star-inserted&quot;]/section[@class=&quot;contact-details ng-star-inserted&quot;]/section[@class=&quot;practitioner-verification ng-star-inserted&quot;]/section[@class=&quot;input-otp ng-star-inserted&quot;]/x-textfield[1]/div[@class=&quot;x-i-textfield-wrapper&quot;]/div[@class=&quot;ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Resend'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/x-textfield/div/div</value>
   </webElementXpaths>
</WebElementEntity>
