<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_Start Time_ng-untouched ng-pristine ng-valid</name>
   <tag></tag>
   <elementGuidId>e8be6895-7783-4dd2-bce6-88f980e0000f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>typehead.field.mr-3.ng-untouched.ng-pristine.ng-valid > div.dropdown-wrapper > div.content > input.ng-untouched.ng-pristine.ng-valid</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//input[@type='text'])[13]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>text</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-form</name>
      <type>Main</type>
      <value>[object Object]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>placeholder</name>
      <type>Main</type>
      <value>Start Time</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-untouched ng-pristine ng-valid</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-view-schedule[@class=&quot;ng-star-inserted&quot;]/modal[@class=&quot;ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-animated&quot;]/div[@class=&quot;content ng-tns-c29-7 ng-star-inserted&quot;]/app-manage-slot-modal[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;form-group modal-wrapper&quot;]/div[@class=&quot;row m-0 col pt-3&quot;]/div[@class=&quot;col p-0 mr-4&quot;]/typehead[@class=&quot;field mr-3 ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;content&quot;]/input[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//input[@type='text'])[13]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/typehead/div/div[2]/input</value>
   </webElementXpaths>
</WebElementEntity>
