<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_LOGIN</name>
   <tag></tag>
   <elementGuidId>6122b5fa-5b91-4182-9fc6-7500a8e2294c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.x-btn-primary.hover > div.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Login with username'])[1]/following::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> LOGIN</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-login[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;wrapper&quot;]/rg-sso[1]/main[@class=&quot;rg-sso-main&quot;]/aside[@class=&quot;main-content&quot;]/div[@class=&quot;col-xs-4 col-sm-5 col-md-7 col-lg-8 view-container&quot;]/div[@class=&quot;screens-container&quot;]/rg-login[@class=&quot;ng-star-inserted&quot;]/section[@class=&quot;login-section&quot;]/section[@class=&quot;first-part&quot;]/section[@class=&quot;login-actions&quot;]/btn-primary[1]/x-button[1]/button[@class=&quot;x-btn-primary hover&quot;]/div[@class=&quot;ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login with username'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot Password?'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/div</value>
   </webElementXpaths>
</WebElementEntity>
