<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Andaman and Nicobar Islands</name>
   <tag></tag>
   <elementGuidId>32e1a3b8-361e-4931-88ee-24fd4bec89a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='State / UT'])[1]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-class</name>
      <type>Main</type>
      <value>[object Object]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Andaman and Nicobar Islands</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/doc-patient-profile[@class=&quot;ng-star-inserted&quot;]/modal-slide[@class=&quot;text-center ng-tns-c25-7 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c25-7 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-slideIn&quot;]/div[@class=&quot;edit-patient-wrapper&quot;]/edit-patient-details[1]/form[@class=&quot;patient-details-form ng-untouched ng-pristine ng-invalid&quot;]/app-patient-address-form[@class=&quot;ng-untouched ng-valid ng-dirty&quot;]/div[@class=&quot;row address&quot;]/div[@class=&quot;container-fluid ng-untouched ng-valid ng-dirty&quot;]/div[@class=&quot;address-fields&quot;]/div[@class=&quot;row&quot;]/x-dropdowns[@class=&quot;half-textfield col-xs-4 col-sm-8 col-md-8 col-lg-6 ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;x-i-dropdown-wrapper&quot;]/div[@class=&quot;x-i-content ng-star-inserted&quot;]/ul[1]/li[@class=&quot;ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State / UT'])[1]/following::li[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yemen'])[1]/following::li[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Andhra Pradesh'])[1]/preceding::li[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Arunachal Pradesh'])[1]/preceding::li[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Andaman and Nicobar Islands']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//x-dropdowns[2]/div/div[3]/ul/li</value>
   </webElementXpaths>
</WebElementEntity>
