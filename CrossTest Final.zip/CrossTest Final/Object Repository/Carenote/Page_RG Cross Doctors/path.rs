<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path</name>
   <tag></tag>
   <elementGuidId>d8e4c6e0-d56d-45e7-aab2-281113d47928</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>app-close-icon > svg > g > g > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M0 0h24v24H0z</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/app-carenote[1]/modal[@class=&quot;ng-tns-c29-1&quot;]/div[@class=&quot;contain ng-tns-c29-1 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-animated&quot;]/header[@class=&quot;carenote-header ng-star-inserted&quot;]/section[@class=&quot;header-right-content&quot;]/div[@class=&quot;modal-actions&quot;]/button[@class=&quot;btn-close&quot;]/app-close-icon[1]/svg[1]/g[1]/g[1]/path[1]</value>
   </webElementProperties>
</WebElementEntity>
