<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Date range_left-icon x-i-left-caret small_74df68</name>
   <tag></tag>
   <elementGuidId>daffc28e-6a07-4613-b053-f5250d9a8c19</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>dropdown-v2.ng-untouched.ng-pristine.ng-valid > div.dropdown-wrapper > div.content > i.left-icon.x-i-left-caret.small.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//dropdown-v2/div/div[2]/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>left-icon x-i-left-caret small ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-style</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-dashboard[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;background col-12 row&quot;]/div[@class=&quot;dropdown-container col-3&quot;]/dropdown-v2[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;content&quot;]/i[@class=&quot;left-icon x-i-left-caret small ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dropdown-v2/div/div[2]/i</value>
   </webElementXpaths>
</WebElementEntity>
