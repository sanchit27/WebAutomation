<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Hi Doctor91911Login with username LOGIN_758d55</name>
   <tag></tag>
   <elementGuidId>ef9ab3e6-f4e5-465f-97a9-f90ea28393eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-xs-4.col-sm-5.col-md-7.col-lg-8.view-container</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//aside/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-xs-4 col-sm-5 col-md-7 col-lg-8 view-container</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Hi Doctor,
   +91   +91   +1Login with username LOGINForgot Password?Don’t have a RoundGlass account?SIGN UP LEARN MORE</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-login[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;wrapper&quot;]/rg-sso[1]/main[@class=&quot;rg-sso-main&quot;]/aside[@class=&quot;main-content&quot;]/div[@class=&quot;col-xs-4 col-sm-5 col-md-7 col-lg-8 view-container&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//aside/div</value>
   </webElementXpaths>
</WebElementEntity>
