<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_2</name>
   <tag></tag>
   <elementGuidId>fa9864f0-b8e2-4d8d-b729-6b02b7fa4144</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Patients*'])[2]/following::li[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 2 </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-view-schedule[@class=&quot;ng-star-inserted&quot;]/modal[@class=&quot;ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-animated&quot;]/div[@class=&quot;content ng-tns-c29-7 ng-star-inserted&quot;]/app-manage-slot-modal[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;form-group modal-wrapper&quot;]/div[@class=&quot;row m-0 pt-3 ng-star-inserted&quot;]/div[@class=&quot;col&quot;]/app-schedule-consultation-select[@class=&quot;row m-0&quot;]/div[@class=&quot;col p-0&quot;]/dropdown-v2[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;dropdown-content ng-star-inserted&quot;]/ul[1]/li[@class=&quot;ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Patients*'])[2]/following::li[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Duration*'])[2]/following::li[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Time*'])[1]/preceding::li[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='End Time*'])[1]/preceding::li[25]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/app-schedule-consultation-select/div[2]/dropdown-v2/div/div[3]/ul/li[2]</value>
   </webElementXpaths>
</WebElementEntity>
