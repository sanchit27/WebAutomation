<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>header_NOTIFICATIONSMark all as read</name>
   <tag></tag>
   <elementGuidId>7aad65b3-14cb-453f-98f2-6b29a964ea84</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>header.notify-list-heading.d-flex.align-items-center.justify-content-between.px-3.pb-3.pt-2.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='RANDOM'])[1]/following::header[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>header</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>notify-list-heading d-flex align-items-center justify-content-between px-3 pb-3 pt-2 ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NOTIFICATIONSMark all as read</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/app-header[1]/div[@class=&quot;header fixed-top&quot;]/div[@class=&quot;main-container container-fluid&quot;]/nav[@class=&quot;navbar nav nav-large&quot;]/div[@class=&quot;navbar-right&quot;]/div[@class=&quot;nav-btn login logged-in ng-star-inserted&quot;]/div[@class=&quot;notifs-wrapper&quot;]/div[@class=&quot;notifs-dropdown popover ng-star-inserted&quot;]/div[@class=&quot;bottom clinic notifs&quot;]/header[@class=&quot;notify-list-heading d-flex align-items-center justify-content-between px-3 pb-3 pt-2 ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RANDOM'])[1]/following::header[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Out'])[1]/following::header[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//header</value>
   </webElementXpaths>
</WebElementEntity>
