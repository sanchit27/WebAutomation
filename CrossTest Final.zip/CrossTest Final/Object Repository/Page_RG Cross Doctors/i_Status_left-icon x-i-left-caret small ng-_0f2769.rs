<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Status_left-icon x-i-left-caret small ng-_0f2769</name>
   <tag></tag>
   <elementGuidId>9a7b30ee-5280-42e2-abe0-c7f179a03945</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>dropdown-v2.field.mr-3.ng-untouched.ng-pristine.ng-valid > div.dropdown-wrapper > div.content > i.left-icon.x-i-left-caret.small.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//dropdown-v2/div/div[2]/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>left-icon x-i-left-caret small ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-style</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-statements-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;statements-container p-4&quot;]/div[@class=&quot;statement-list-container&quot;]/div[@class=&quot;statement-filter-container row m-0 px-4 pt-2 pb-1&quot;]/div[@class=&quot;col-2 pl-0 pr-4&quot;]/dropdown-v2[@class=&quot;field mr-3 ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;content&quot;]/i[@class=&quot;left-icon x-i-left-caret small ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dropdown-v2/div/div[2]/i</value>
   </webElementXpaths>
</WebElementEntity>
