<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>img</name>
   <tag></tag>
   <elementGuidId>899f7a8e-e6bd-4fc3-be9b-0f0bf701f109</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>img[title=&quot;Go to Bill Settings&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//img[@title='Go to Bill Settings']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to Bill Settings</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>https://static.crosshealthexchange.com/ui/dev/images/rg-doctors/settings.svg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-statements-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;statements-container p-4&quot;]/div[@class=&quot;statement-heading row m-0 mb-4&quot;]/div[@class=&quot;statement-actions row m-0&quot;]/div[@class=&quot;icon-tile center-div&quot;]/img[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <type>Main</type>
      <value>//img[@title='Go to Bill Settings']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/img</value>
   </webElementXpaths>
</WebElementEntity>
