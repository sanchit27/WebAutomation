<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Appointment DateMarch2021SUNMONTUEWEDTH_397ed0</name>
   <tag></tag>
   <elementGuidId>597716df-4abd-4a9d-9d62-0b199c4a26a5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Automation'])[4]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.form-group-wrapper.date-time</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-group-wrapper date-time</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Appointment Date*March2021SUNMONTUEWEDTHUFRISAT12345678910111213141516171819202122232425262728293031MORNINGAFTERNOONEVENING NA  NA  NA  NA  NA  NA  NA  NA  NA  12:00 PM 0 1:00 PM 0 2:00 PM 0 3:00 PM 0 4:00 PM 0 12:00 PM 0 1:00 PM 0 3:00 PM 0 4:00 PM 0 5:00 PM 0 5:00 PM 0 6:00 PM 0 NA  NA  NA  NA  NA  NA </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/modal-slide[@class=&quot;text-center ng-tns-c25-6 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c25-6 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-slideIn&quot;]/aside[@class=&quot;appointments-right&quot;]/add-new-appointment[1]/section[@class=&quot;add-appointment-wrapper&quot;]/div[@class=&quot;accordian&quot;]/div[@class=&quot;appointment-details-tab&quot;]/div[@class=&quot;accordian-body open&quot;]/add-appointment[1]/form[@class=&quot;add-appointment-form ng-untouched ng-invalid ng-dirty&quot;]/div[@class=&quot;form-group-wrapper date-time&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Automation'])[4]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='e-Consult'])[3]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//add-appointment/form/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
