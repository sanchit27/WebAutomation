<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Ira        Chaturvedi</name>
   <tag></tag>
   <elementGuidId>708eb9c8-02dd-4e61-8c2b-06c4e6e28968</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='BHEL Employee Id'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.patient-name</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>patient-name</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ira
        Chaturvedi</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/modal-slide[@class=&quot;text-center ng-tns-c25-6 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c25-6 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-slideIn&quot;]/aside[@class=&quot;appointments-right&quot;]/add-new-appointment[1]/section[@class=&quot;add-appointment-wrapper&quot;]/div[@class=&quot;accordian&quot;]/div[@class=&quot;basic-details-tab&quot;]/div[@class=&quot;accordian-body open&quot;]/app-search-patient[1]/form[@class=&quot;ng-untouched ng-dirty ng-valid&quot;]/div[@class=&quot;form-group search-patient caregroup-search-patient&quot;]/div[@class=&quot;caregroup-search ng-star-inserted&quot;]/x-dropdowns[@class=&quot;ng-untouched ng-dirty ng-valid&quot;]/div[@class=&quot;x-i-dropdown-wrapper&quot;]/div[@class=&quot;x-i-content ng-star-inserted&quot;]/ul[1]/li[@class=&quot;ng-star-inserted&quot;]/p[@class=&quot;patient-name&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BHEL Employee Id'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Patient ID'])[3]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NEXT'])[1]/preceding::p[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEARCH PATIENT*'])[1]/preceding::p[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/p</value>
   </webElementXpaths>
</WebElementEntity>
