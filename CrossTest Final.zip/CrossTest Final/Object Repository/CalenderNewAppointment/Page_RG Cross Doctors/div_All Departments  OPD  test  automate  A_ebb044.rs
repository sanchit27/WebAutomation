<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_All Departments  OPD  test  automate  A_ebb044</name>
   <tag></tag>
   <elementGuidId>4314b883-9adf-4cbc-8f72-6c81471b86ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Get help'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.content.flex-grow-1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>content flex-grow-1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> All Departments  OPD  test  automate  Automation  testing  All Doctors  Dr. Abhayam Rastogi March2021SUNMONTUEWEDTHUFRISAT12345678910111213141516171819202122232425262728293031DAYWEEKMONTH1 APPTS0 In Clinic0 CHECK IN0 CANCELLED0 CHECK OUT0 IN ASSESSMENT0 IN CONSULTATION0 No Show 0 Delayed 0 Pending 0 Incomplete Dr. Abhayam RastogiTODAY10:00 AM - 6:00 PM11:00 AM - 2:00 PM3:00 PM - 7:00 PM All Appointments  auto  test  ewrwr  CONSULTATION  e-Consult  Automation  Online Consultation Appointments between 6:00 PM and 7:00 PM. Use previous/next buttons to see more. Ira Chaturvedi  ,   5 yr.old  Female  +91-9014827517 N/A Dr. Abhayam Rastogi  Service : CONSULTATION  Walk in  Reschedule  Cancel  History  6:00 PM </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get help'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Details'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
