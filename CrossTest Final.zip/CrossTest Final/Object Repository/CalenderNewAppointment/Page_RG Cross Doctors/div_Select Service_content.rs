<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select Service_content</name>
   <tag></tag>
   <elementGuidId>c3cddd3c-5a7d-4a0e-bbe8-eceb2b5e35ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Service*'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>typehead.field.mr-3.mt-4.ng-untouched.ng-pristine.ng-invalid.ng-star-inserted > div.dropdown-wrapper > div.content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-klass</name>
      <type>Main</type>
      <value>content</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-class</name>
      <type>Main</type>
      <value>[object Object]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/modal-slide[@class=&quot;text-center ng-tns-c25-6 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c25-6 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-slideIn&quot;]/aside[@class=&quot;appointments-right&quot;]/add-new-appointment[1]/section[@class=&quot;add-appointment-wrapper&quot;]/div[@class=&quot;accordian&quot;]/div[@class=&quot;appointment-details-tab&quot;]/div[@class=&quot;accordian-body open&quot;]/add-appointment[1]/form[@class=&quot;add-appointment-form ng-untouched ng-invalid ng-dirty&quot;]/div[@class=&quot;form-group flex-wrap mt-0&quot;]/typehead[@class=&quot;field mr-3 mt-4 ng-untouched ng-pristine ng-invalid ng-star-inserted&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;content&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Service*'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NEXT'])[2]/following::div[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='auto'])[2]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[4]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//add-appointment/form/div/typehead/div/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
