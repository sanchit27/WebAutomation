<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Patients_left-icon x-i-left-caret small n_f296ff</name>
   <tag></tag>
   <elementGuidId>0f38b54f-1087-40bc-9674-e2907cfdef3c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>dropdown-v2.ng-untouched.ng-pristine.ng-valid > div.dropdown-wrapper > div.content > i.left-icon.x-i-left-caret.small.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[2]/dropdown-v2/div/div[2]/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>left-icon x-i-left-caret small ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-style</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-view-services-schedule[@class=&quot;ng-star-inserted&quot;]/modal[@class=&quot;ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-animated&quot;]/div[@class=&quot;content ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;modal-container ng-star-inserted&quot;]/app-service-form[1]/div[@class=&quot;service-wrapper&quot;]/form[@class=&quot;px-4 ng-untouched ng-dirty ng-valid&quot;]/div[@class=&quot;form-group mb-3&quot;]/app-schedule-consultation-select[@class=&quot;row m-0 col p-0&quot;]/div[@class=&quot;col p-0&quot;]/dropdown-v2[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;content&quot;]/i[@class=&quot;left-icon x-i-left-caret small ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/dropdown-v2/div/div[2]/i</value>
   </webElementXpaths>
</WebElementEntity>
