<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_15 minutes</name>
   <tag></tag>
   <elementGuidId>63c97651-622c-4b07-8942-cbe481f5780c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>dropdown-v2.ng-untouched.ng-pristine.ng-valid > div.dropdown-wrapper > div.dropdown-content.ng-star-inserted > ul > li.selected.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Duration*'])[1]/following::li[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>selected ng-star-inserted</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 15 minutes </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-practitioner-post-login[@class=&quot;ng-star-inserted&quot;]/main[@class=&quot;app-container d-flex flex-column&quot;]/div[@class=&quot;wrapper d-flex&quot;]/div[@class=&quot;content flex-grow-1&quot;]/app-view-services-schedule[@class=&quot;ng-star-inserted&quot;]/modal[@class=&quot;ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;contain ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;dialog ng-trigger ng-trigger-animated&quot;]/div[@class=&quot;content ng-tns-c29-7 ng-star-inserted&quot;]/div[@class=&quot;modal-container ng-star-inserted&quot;]/app-service-form[1]/div[@class=&quot;service-wrapper&quot;]/form[@class=&quot;px-4 ng-untouched ng-dirty ng-valid&quot;]/div[@class=&quot;form-group mb-3&quot;]/app-schedule-consultation-select[@class=&quot;row m-0 col p-0&quot;]/div[@class=&quot;col p-0 mr-4&quot;]/dropdown-v2[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;dropdown-wrapper&quot;]/div[@class=&quot;dropdown-content ng-star-inserted&quot;]/ul[1]/li[@class=&quot;selected ng-star-inserted&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Duration*'])[1]/following::li[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Service Description*'])[1]/following::li[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Patients*'])[1]/preceding::li[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save Preference'])[1]/preceding::li[15]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='15 minutes']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dropdown-v2/div/div[3]/ul/li[3]</value>
   </webElementXpaths>
</WebElementEntity>
